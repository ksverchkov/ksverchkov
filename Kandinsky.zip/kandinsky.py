import requests as r
from requests_html import HTMLSession
import json as j
import base64
import os
import random
import string
import base64
from PIL import Image
import io
from time import sleep

session = HTMLSession()

apiUrl = 'https://fusionbrain.ai'

styles = []


def generate_boundary():
  boundary = ''.join(random.choices(string.ascii_letters + string.digits,
                                    k=16))
  return boundary


def send_request_with_cookies(textQuery,
                              style='',
                              preset='1',
                              queueType='generate',
                              cookies={}):
  url = apiUrl + '/api/v1/text2image/run'  #Setting url

  # Creating boundary
  boundary = generate_boundary()

  headers = {
    'Accept':
    'application/json, text/plain, */*',
    'Accept-Encoding':
    'gzip, deflate, br',
    'Accept-Language':
    'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    'Connection':
    'keep-alive',
    "content-type":
    f"multipart/form-data; boundary=----WebKitFormBoundary{boundary}",
    'Host':
    'fusionbrain.ai',
    'Origin':
    'https://fusionbrain.ai',
    'Referer':
    'https://fusionbrain.ai/diffusion',
    'sec-ch-ua':
    '"Chromium";v="105", "Not)A;Brand";v="8"',
    'sec-ch-ua-mobile':
    '?0',
    'sec-ch-ua-platform':
    '"Linux"',
    'Sec-Fetch-Dest':
    'empty',
    'Sec-Fetch-Mode':
    'cors',
    'Sec-Fetch-Site':
    'same-origin',
    'User-Agent':
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36  SberBrowser/3.1.0.0'
  }  # Request headers

  form_data = f'------WebKitFormBoundary{boundary}\r\nContent-Disposition: form-data; name=\"queueType\"\r\n\r\n{queueType}\r\n------WebKitFormBoundary{boundary}\r\nContent-Disposition: form-data; name=\"query\"\r\n\r\n{textQuery}\r\n------WebKitFormBoundary{boundary}\r\nContent-Disposition: form-data; name=\"preset\"\r\n\r\n{preset}\r\n------WebKitFormBoundary{boundary}\r\nContent-Disposition: form-data; name=\"style\"\r\n\r\n{style}\r\n------WebKitFormBoundary{boundary}--\r\n'  # Setting form data with boundaries
  form_data = form_data.encode('utf-8')  # Encoding to needed format

  # Form data for sending

  session = HTMLSession()
  response = session.post(url,
                          cookies=cookies,
                          headers=headers,
                          data=form_data)  # Sending request

  return response.json()  # Returing response


def generateImage(textQuery, imageName, style=''):
  # Getting to website at first to get cookies
  request = session.get(
    f"{apiUrl}/diffusion")  # Getting request to main page for cookies
  cookies = session.cookies  # Getting cookies

  response = send_request_with_cookies(
    textQuery, cookies=cookies)  # Sending generation request

  entity = response['result']['pocketId']  # Getting id of the image

  sleep(30)  # Waiting 30 seconds to generate image

  entitiesRequest = session.get(
    f'{apiUrl}/api/v1/text2image/generate/pockets/{entity}/entities',
    cookies=cookies)  # Getting result image entity response

  image = entitiesRequest.json()["result"][0]["response"][
    0]  # Getting image base64 data from entity response

  image_data = base64.b64decode(image)  # Decoding image data

  image = Image.open(
    io.BytesIO(image_data))  # Transforming base64 bytes to image

  image.save(imageName + '.png', 'PNG')  # Saving image

  return imageName + '.png'

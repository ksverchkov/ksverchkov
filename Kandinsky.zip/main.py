import kandinsky
import telebot
import random, string
import config
import requests as r
import os
import requests
import io
import base64
from PIL import Image



"""
photo = anime.generatePhoto('photos.jpg')
if photo:
  print("Successfully got file: " + photo)
else:
  print("Have an error")
"""

def randomword(length):
  letters = string.ascii_lowercase
  return ''.join(random.choice(letters) for i in range(length))

bot = telebot.TeleBot(config.TOKEN)

@bot.message_handler(commands=['start'])
def welcome(message):
  bot.send_message(message.chat.id, config.startMessage)


@bot.message_handler(content_types=['text'])
def lalala(message):
  bot.send_message(message.chat.id, 'Генерация началась. Она займет около 30-40 секунд.')
  fileName = randomword(10)
  photo = kandinsky.generateImage(message.text , fileName)
  if (photo):
    bot.send_photo(message.chat.id, photo=open(photo, 'rb'))
    os.remove(photo)
  else:
    bot.send_message(message.chat.id, "Error occurred. Try again")


while True:
  try:
    bot.polling(none_stop=True)
    pass
  except:
    pass
